import React from 'react';
import './Planer.css';

const Planer = () => (
  <div className="Planer">
    Planer Component
  </div>
);

Planer.propTypes = {};

Planer.defaultProps = {};

export default Planer;
